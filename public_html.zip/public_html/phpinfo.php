<?php phpinfo(); ?>
